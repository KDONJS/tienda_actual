<?php

define("RUTA","http://localhost/tienda_actual/public");

require_once("librerias/MySQLdb.php");
require_once("librerias/Controlador.php");
require_once("librerias/Control.php");


?>