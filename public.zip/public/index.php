<?php
require_once("../app/inicio.php");
$control = new Control();

?>